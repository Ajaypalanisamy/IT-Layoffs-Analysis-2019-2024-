create database it_layoff ;
use it_layoff;

#  ** Preparing Data base **

select COUNT(*) FROM cleaned_layoff;
select * from cleaned_layoff  ;

ALTER TABLE cleaned_layoff
RENAME COLUMN ï»¿Company_Name TO Company_Name;


SELECT DISTINCT TRIM(Company_Name) AS Company_Name
FROM cleaned_layoff
ORDER BY Company_Name;

SET SQL_SAFE_UPDATES = 0;

UPDATE cleaned_layoff
SET Company_Name = TRIM(Company_Name);

alter table cleaned_layoff
add column Layoff_Date_backup varchar(50);

update cleaned_layoff
set Layoff_Date_backup = Layoff_Date ;

UPDATE cleaned_layoff
SET Layoff_Date = STR_TO_DATE(Layoff_Date, '%d-%m-%Y');

UPDATE cleaned_layoff
SET Country = TRIM(UPPER(Country));

alter table cleaned_layoff
add column profit_change_backup varchar(50);

update cleaned_layoff
set profit_change_backup ='Profit_Change(%)';

UPDATE cleaned_layoff
SET `Profit_Change(%)` = TRIM(REPLACE(`Profit_Change(%)`, '%', ''));

ALTER TABLE cleaned_layoff 
MODIFY COLUMN `Profit_Change(%)` DECIMAL(10,2);

SELECT `Profit_Change(%)`
FROM cleaned_layoff
LIMIT 20;

UPDATE cleaned_layoff
SET `Remote_Work_Ratio(%)` = TRIM(REPLACE(`Remote_Work_Ratio(%)`, '%', ''));

ALTER TABLE cleaned_layoff 
MODIFY COLUMN `Remote_Work_Ratio(%)` DECIMAL(10,2);
#----------------------------------------------------------------------------------------------------------------------------

 # ** Finding  Queries and insights **

# 1. Find the total number of employees laid off by each company.

select Company_Name , sum(Employees_Laid_off) as total_layoff
from cleaned_layoff
group by company_name 
order by total_layoff;

#----------------------------------------------------------------------------------------------------------------------------

# 2. List all unique industries where layoffs occurred.

select Industry ,sum(Employees_Laid_Off) as lay_off
from cleaned_layoff 
where Industry is not null
group by Industry;

#----------------------------------------------------------------------------------------------------------------------------
# 3. Find all layoffs that happened in the year 2023. 

SELECT 
    Company_Name,
    Country,
    Layoff_Date,
    SUM(Employees_Laid_Off) AS total_layoff_2023,
    Total_Employees_Before,
    ROUND((SUM(Employees_Laid_Off) / Total_Employees_Before) * 100, 2) AS Layoff_Percentage,
    Reason_for_Layoff,
    Industry
FROM cleaned_layoff
WHERE YEAR(Layoff_Date) = 2023
GROUP BY 
    Company_Name,
    Country,
    Layoff_Date,
    Total_Employees_Before,
    Reason_for_Layoff,
    Industry
ORDER BY total_layoff_2023 DESC;
#----------------------------------------------------------------------------------------------------------------------------

# 4. Show the top 5 companies with the highest layoffs overall.

select Company_Name ,sum(Employees_Laid_Off) as overall_layoffs
from cleaned_layoff
group by Company_Name 
order by overall_layoffs desc 
limit 5 ;
#----------------------------------------------------------------------------------------------------------------------------
# 5. Count the number of layoffs that happened in each country.

select  Country, sum(Employees_Laid_Off) as layoff_count 
from cleaned_layoff
group by Country
order by layoff_count desc ;
#----------------------------------------------------------------------------------------------------------------------------
# 6 . Find the average profit change percentage by industry.

SELECT 
    Industry,
    ROUND(AVG(`Profit_Change(%)`), 2) AS Avg_Profit_Change_Percentage
FROM 
    cleaned_layoff
GROUP BY 
    Industry
ORDER BY 
    Avg_Profit_Change_Percentage DESC;
#----------------------------------------------------------------------------------------------------------------------------
# 7 . Find companies that experienced a revenue increase after layoffs.

SELECT 
    Company_Name,
    Industry,
    Revenue_Before_Layoff,
    Revenue_After_Layoff
FROM 
    cleaned_layoff
WHERE 
    CAST(REPLACE(Revenue_After_Layoff, ',', '') AS DECIMAL(15,2)) >
    CAST(REPLACE(Revenue_Before_Layoff, ',', '') AS DECIMAL(15,2))
ORDER BY 
    CAST(REPLACE(Revenue_After_Layoff, ',', '') AS DECIMAL(15,2)) DESC;
    
  #----------------------------------------------------------------------------------------------------------------------------  
# 8 . Show all records where stock price decreased after layoffs.

select
      Company_Name,
      Industry,
      Stock_Price_Before,
      Stock_Price_After
from 
     cleaned_layoff
where 
      Stock_Price_After < Stock_Price_Before
order by 
       Stock_Price_After desc ;
	#----------------------------------------------------------------------------------------------------------------------------
# 9. Get the number of layoffs where companies had a hiring freeze.

SELECT 
    Company_Name,
    SUM(Employees_Laid_Off) AS Total_Layoff,
    Hiring_Freeze
FROM 
    cleaned_layoff
WHERE 
    TRIM(LOWER(Hiring_Freeze)) = 'yes'
GROUP BY 
    Company_Name, Hiring_Freeze
ORDER BY 
    Total_Layoff DESC;
#----------------------------------------------------------------------------------------------------------------------------
#10. Find the average remote work ratio (%) by country.

SELECT 
    Country,
    ROUND(AVG(`Remote_Work_Ratio(%)`), 2) AS Avg_Remote_Work_Ratio
FROM 
    cleaned_layoff
GROUP BY 
    Country
ORDER BY 
    Avg_Remote_Work_Ratio DESC;
#----------------------------------------------------------------------------------------------------------------------------

# 11 .Find the company with the highest profit improvement (maximum positive Profit_Change%). 

SELECT  
    Company_Name,
    Country,
    Industry,
    MAX(`Profit_Change(%)`) AS Highest_Profit
FROM 
    cleaned_layoff
GROUP BY 
    Company_Name, Country, Industry
ORDER BY 
    Highest_Profit DESC
LIMIT 5;


#----------------------------------------------------------------------------------------------------------------------------

# 12 . Rank industries based on their total layoffs.

SELECT 
    Industry,
    SUM(Employees_Laid_Off) AS Total_Layoffs,
    RANK() OVER (ORDER BY SUM(Employees_Laid_Off) DESC) AS Industry_Rank
FROM 
    cleaned_layoff
GROUP BY 
    Industry
ORDER BY 
    Total_Layoffs DESC;
    
#----------------------------------------------------------------------------------------------------------------------------

# 13 . Calculate year-over-year layoffs for each company.

SELECT 
    Company_Name,
    YEAR(Layoff_Date) AS Year,
    SUM(Employees_Laid_Off) AS Total_Layoffs,
    LAG(SUM(Employees_Laid_Off)) OVER (PARTITION BY Company_Name ORDER BY YEAR(Layoff_Date)) AS Prev_Year_Layoffs,
    ROUND(
        ((SUM(Employees_Laid_Off) - LAG(SUM(Employees_Laid_Off)) OVER (PARTITION BY Company_Name ORDER BY YEAR(Layoff_Date))) 
        / LAG(SUM(Employees_Laid_Off)) OVER (PARTITION BY Company_Name ORDER BY YEAR(Layoff_Date)) * 100), 2
    ) AS YoY_Change_Percentage
FROM 
    cleaned_layoff
GROUP BY 
    Company_Name, YEAR(Layoff_Date)
ORDER BY 
    Company_Name, Year;

#----------------------------------------------------------------------------------------------------------------------------

# 14 . Compare pre- and post-layoff stock prices for each company and find the percentage change.

SELECT 
	distinct Company_Name,
    Industry
    Stock_Price_Before,
    Stock_Price_After,
    ROUND(
        (
            (Stock_Price_After - Stock_Price_Before)
            / Stock_Price_Before
        ), 
        2
    ) AS Stock_Price_Change
FROM 
    cleaned_layoff
WHERE 
    Stock_Price_Before IS NOT NULL 
    AND Stock_Price_After IS NOT NULL
ORDER BY 
    Stock_Price_Change DESC;

#----------------------------------------------------------------------------------------------------------------------------------------

# 15 . Identify the top 3 industries that showed revenue growth despite layoffs.

SELECT 
    Industry,
    ROUND(
        ((SUM(Revenue_After_Layoff) - SUM(Revenue_Before_Layoff)) / SUM(Revenue_Before_Layoff)) * 100, 
        2
    ) AS Revenue_Growth_Percentage
FROM 
    cleaned_layoff
WHERE 
    Revenue_Before_Layoff IS NOT NULL 
    AND Revenue_After_Layoff IS NOT NULL
GROUP BY 
    Industry
HAVING 
    Revenue_Growth_Percentage > 0
ORDER BY 
    Revenue_Growth_Percentage DESC
LIMIT 3;

#-------------------------------------------------------------------------------------------------------------------------------
